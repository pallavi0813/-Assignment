﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2Assignment
{
    class Student2
    {
        public int rollno;
        public string sname;
        public int year;
        public int sem;
        public string branch;
        public Student2(int rollNo, string sName, int year1, int sem1, string branch1)
        {
            this.rollno = rollNo;
            this.sname = sName;
            this.year = year1;
            this.sem = sem1;
            this.branch = branch1;
        }

        public void displayResult(int[] marks)
        {
            int sum = 0;
            int flag=0, flag1=0;
            for (int i = 0; i < 5; i++)
            {
                sum = sum + marks[i];
            }
            double average = sum / 5;
            Console.WriteLine("Average=" + average);
            for (int i = 0; i < 5; i++)
            {

                if (marks[i] < 35)
                {
                    Console.WriteLine("Result=Fail");
                    flag = 1;
                    break;

                }

                else if (marks[i] >= 35 && average < 50)
                {
                    Console.WriteLine("Result=Fail");
                    flag1 = 1;
                    break;


                }
            }
            if(flag!=1&&flag1!=1)
            Console.WriteLine("Result=Pass");

        }

        public void displayDetails()
        {
            Console.WriteLine("rollno=" + rollno);
            Console.WriteLine("Name=" + sname);
            Console.WriteLine("year=" + " " + year + "St year");
            Console.WriteLine("sem=" + sem);
            Console.WriteLine("branch=" + branch);


        }

    }
}
